Employee Attrition Analytics Dashboard

1. Open index.html in a modern browser.
2. Click the CSV file chooser and select your IBM HR Attrition CSV.
3. Dashboard charts and KPIs are calculated locally in the browser.
4. Optional: upload model_comparison.csv exported from your Colab notebook to show actual model metrics.

To publish free using GitHub Pages:
- Create a GitHub repository.
- Upload index.html to the repository root.
- Open Settings > Pages.
- Under Build and deployment, select Deploy from a branch, branch main, folder /(root), then Save.
- Wait for GitHub Pages to publish the URL.

Notes:
- Dashboard runs without Streamlit, Colab tunnels, or a backend.
- Demo data is illustrative and not real employee data.
- Risk chart is a rough illustrative grouping based on observed labels, not predictions from the trained ML model.
